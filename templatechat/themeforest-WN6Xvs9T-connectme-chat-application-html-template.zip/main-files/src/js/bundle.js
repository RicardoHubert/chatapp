// include '../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js'

/*! * include simplebar  */
// include '../../node_modules/simplebar/dist/simplebar.min.js'

/*! * include glightbox ( for popup gallery )  */
// include '../../node_modules/glightbox/dist/js/glightbox.min.js'

/*! * include swiper ( for sliders )  */
// include '../../node_modules/swiper/swiper-bundle.min.js'

/*! * include swiper ( for sliders )  */
// include '../../node_modules/swiper/swiper-bundle.min.js'

/*! * include prism ( for code highliter )  */
// include '../../node_modules/prismjs/prism.js'

/*! * include clipboard ( for copy )  */
// include '../../node_modules/clipboard/dist/clipboard.min.js'

/*! * include custom functions  */
// include './custom/functions.js'